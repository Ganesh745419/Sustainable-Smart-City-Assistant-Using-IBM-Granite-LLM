import React from 'react';
import { Metric, Alert } from './types';

export const ICONS: { [key: string]: React.ReactNode } = {
  Dashboard: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
    </svg>
  ),
  ResidentHub: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  ),
  CityAlerts: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
  ),
};

export const METRICS_DATA: Metric[] = [
  {
    id: 'energy',
    title: 'Energy Consumption',
    value: '7,250',
    unit: 'MWh',
    description: 'Total city-wide energy usage in the last 24 hours.',
    color: '#3498db',
    data: [{ name: 'Day 1', value: 7.1 }, { name: 'Day 2', value: 7.3 }, { name: 'Day 3', value: 7.0 }, { name: 'Day 4', value: 7.25 }],
    dataKey: 'value',
  },
  {
    id: 'traffic',
    title: 'Traffic Flow',
    value: '85',
    unit: '%',
    description: 'Current city-wide traffic efficiency index.',
    color: '#f1c40f',
    data: [{ name: '6am', value: 60 }, { name: '9am', value: 95 }, { name: '12pm', value: 75 }, { name: '3pm', value: 85 }],
    dataKey: 'value',
  },
  {
    id: 'waste',
    title: 'Waste Management',
    value: '450',
    unit: 'Tons',
    description: 'Recycled waste collected today.',
    color: '#2ecc71',
    data: [{ name: 'Mon', value: 420 }, { name: 'Tue', value: 435 }, { name: 'Wed', value: 460 }, { name: 'Thu', value: 450 }],
    dataKey: 'value',
  },
  {
    id: 'air_quality',
    title: 'Air Quality Index',
    value: '35',
    unit: 'AQI',
    description: 'Current average Air Quality Index. Lower is better.',
    color: '#9b59b6',
    data: [{ name: 'Morning', value: 45 }, { name: 'Noon', value: 30 }, { name: 'Afternoon', value: 32 }, { name: 'Evening', value: 35 }],
    dataKey: 'value',
  },
];

export const ALERTS_DATA: Alert[] = [
  {
    id: '1',
    title: 'High Traffic Alert: Downtown Core',
    description: 'Major event at the City Center causing significant traffic delays on Main St and Ocean Ave. Consider alternate routes or public transport.',
    level: 'warning',
    timestamp: '2 hours ago',
  },
  {
    id: '2',
    title: 'Community Event: Park Cleanup',
    description: 'Join the community cleanup at Sunrise Park this Saturday from 9 AM to 12 PM. Gloves and bags will be provided.',
    level: 'info',
    timestamp: '1 day ago',
  },
  {
    id: '3',
    title: 'Power Outage Notification',
    description: 'Scheduled maintenance will cause a power outage in the Northwood district on Friday from 2 AM to 4 AM.',
    level: 'info',
    timestamp: '3 days ago',
  },
   {
    id: '4',
    title: 'Emergency Services Drill',
    description: 'City emergency services are conducting a drill near the waterfront. Expect increased presence of emergency vehicles. This is not a real emergency.',
    level: 'critical',
    timestamp: 'Just now',
  },
];
