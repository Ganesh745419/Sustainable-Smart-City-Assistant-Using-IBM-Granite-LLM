export enum ViewType {
  Dashboard = 'Dashboard',
  ResidentHub = 'ResidentHub',
  CityAlerts = 'CityAlerts',
}

export interface Metric {
  id: string;
  title: string;
  value: string;
  unit: string;
  description: string;
  color: string;
  data: { name: string; value: number }[];
  dataKey: string;
}

export interface Alert {
  id: string;
  title: string;
  description: string;
  level: 'info' | 'warning' | 'critical';
  timestamp: string;
}
