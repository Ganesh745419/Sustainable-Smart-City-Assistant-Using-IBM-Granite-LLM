import React, { useState } from 'react';
import { ViewType } from './types';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './components/dashboard/Dashboard';
import ResidentHub from './components/resident/ResidentHub';
import AlertsView from './components/alerts/AlertsView';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>(ViewType.Dashboard);

  const renderContent = () => {
    switch (currentView) {
      case ViewType.Dashboard:
        return <Dashboard />;
      case ViewType.ResidentHub:
        return <ResidentHub />;
      case ViewType.CityAlerts:
        return <AlertsView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="bg-brand-dark text-brand-text min-h-screen flex">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <div className="flex-1 flex flex-col">
        <Header currentView={currentView} />
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;
