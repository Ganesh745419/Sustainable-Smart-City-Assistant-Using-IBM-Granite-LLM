import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSustainabilityInsights = async (
  metricTitle: string,
  metricData: string
): Promise<string> => {
  try {
    const prompt = `
      You are an expert urban sustainability analyst for a smart city.
      Analyze the following data for "${metricTitle}": ${metricData}.
      Provide a brief, actionable analysis in two parts:
      1.  **Insight:** A concise observation based on the data.
      2.  **Recommendation:** A practical, data-driven suggestion for city officials to improve sustainability related to this metric.
      Format the output as plain text, using Markdown for headers (e.g., **Insight:**).
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error fetching sustainability insights:", error);
    return "Error: Could not retrieve insights from the AI assistant. The service may be temporarily unavailable.";
  }
};


export const getPersonalizedTips = async (
  habits: string
): Promise<string> => {
    try {
        const prompt = `
            You are a friendly and encouraging sustainable living advisor.
            A city resident has shared their habits: "${habits}".
            Based on this, provide 3-5 personalized, actionable, and easy-to-follow tips to help them live more sustainably.
            Focus on practical changes they can make in their daily routine.
            Format the response as a Markdown list. Start with a brief, encouraging opening sentence.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
        });
        
        return response.text;
    } catch (error) {
        console.error("Error fetching personalized tips:", error);
        return "Error: Could not retrieve personalized tips. Please try again later.";
    }
};
