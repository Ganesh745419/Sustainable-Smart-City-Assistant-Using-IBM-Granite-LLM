import React, { useState, useCallback } from 'react';
import { getPersonalizedTips } from '../../services/geminiService';
import Spinner from '../common/Spinner';

const ResidentHub: React.FC = () => {
  const [habits, setHabits] = useState('');
  const [tips, setTips] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGetTips = useCallback(async () => {
    if (!habits.trim()) {
      setTips('Please describe your habits first to get personalized tips.');
      return;
    }
    setIsLoading(true);
    setTips('');
    const result = await getPersonalizedTips(habits);
    setTips(result);
    setIsLoading(false);
  }, [habits]);

  const formattedTips = tips.split('\n').map((line, index) => {
    if (line.startsWith('* ') || line.startsWith('- ')) {
      return (
        <li key={index} className="flex items-start space-x-3">
          <span className="text-brand-accent mt-1">&#10003;</span>
          <span>{line.substring(2)}</span>
        </li>
      );
    }
     if (line.trim() !== '') {
        return <p key={index} className="mb-2">{line}</p>;
    }
    return null;
  });

  return (
    <div className="bg-brand-gray border border-gray-700 rounded-xl p-6 lg:p-8 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-brand-text mb-2">Resident Sustainability Hub</h2>
      <p className="text-brand-subtle mb-6">Get personalized AI-powered tips to reduce your carbon footprint. Describe your daily commute, energy use at home, or shopping habits below.</p>

      <div className="mb-6">
        <label htmlFor="habits" className="block text-sm font-medium text-brand-text mb-2">
          Describe your daily habits:
        </label>
        <textarea
          id="habits"
          rows={5}
          className="w-full bg-brand-dark border border-gray-600 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:outline-none transition"
          placeholder="e.g., 'I drive a gas car 20 miles to work every day, usually leave the lights on, and I'm interested in recycling more effectively.'"
          value={habits}
          onChange={(e) => setHabits(e.target.value)}
          disabled={isLoading}
        />
      </div>

      <button
        onClick={handleGetTips}
        disabled={isLoading || !habits.trim()}
        className="w-full bg-brand-accent text-white font-bold py-3 px-4 rounded-lg hover:bg-opacity-90 transition-all duration-200 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isLoading ? <Spinner /> : 'Get My Green Tips'}
      </button>

      {tips && (
        <div className="mt-8 p-6 bg-brand-dark border border-gray-700 rounded-lg">
          <h3 className="text-xl font-semibold text-brand-text mb-4">Your Personalized Recommendations:</h3>
          <ul className="space-y-3 text-brand-subtle">{formattedTips}</ul>
        </div>
      )}
    </div>
  );
};

export default ResidentHub;
