import React from 'react';
import Spinner from './Spinner';

interface InsightModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  content: string;
  isLoading: boolean;
}

const InsightModal: React.FC<InsightModalProps> = ({ isOpen, onClose, title, content, isLoading }) => {
  if (!isOpen) return null;

  const formattedContent = content.split('\n').map((line, index) => {
    if (line.startsWith('**') && line.endsWith('**')) {
      return <h4 key={index} className="text-lg font-semibold text-brand-accent mt-4 mb-2">{line.replace(/\*\*/g, '')}</h4>;
    }
    if (line.startsWith('* ')) {
        return <li key={index} className="text-brand-subtle">{line.substring(2)}</li>
    }
    return <p key={index} className="text-brand-subtle mb-2">{line}</p>;
  });


  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-brand-gray border border-gray-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <header className="flex justify-between items-center p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-brand-text">AI Insights: {title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">&times;</button>
        </header>
        <div className="p-6 overflow-y-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-48">
                <Spinner />
                <p className="mt-4 text-brand-subtle">Analyzing data and generating insights...</p>
            </div>
          ) : (
            <div>{formattedContent}</div>
          )}
        </div>
        <footer className="p-4 border-t border-gray-700">
          <button 
            onClick={onClose} 
            className="w-full sm:w-auto float-right bg-brand-primary text-white font-semibold py-2 px-6 rounded-lg hover:bg-opacity-80 transition-colors duration-200"
          >
            Close
          </button>
        </footer>
      </div>
    </div>
  );
};

export default InsightModal;
