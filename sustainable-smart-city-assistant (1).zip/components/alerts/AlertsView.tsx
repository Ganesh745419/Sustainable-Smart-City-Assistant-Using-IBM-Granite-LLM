import React from 'react';
import { ALERTS_DATA } from '../../constants';
import { Alert } from '../../types';

const AlertCard: React.FC<{ alert: Alert }> = ({ alert }) => {
  const levelStyles = {
    info: {
      icon: 'ℹ️',
      borderColor: 'border-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    warning: {
      icon: '⚠️',
      borderColor: 'border-yellow-500',
      bgColor: 'bg-yellow-500/10'
    },
    critical: {
      icon: '🚨',
      borderColor: 'border-red-500',
      bgColor: 'bg-red-500/10'
    },
  };

  const styles = levelStyles[alert.level];

  return (
    <div className={`p-4 rounded-lg border-l-4 ${styles.borderColor} ${styles.bgColor} flex space-x-4`}>
        <div className="text-2xl">{styles.icon}</div>
        <div>
            <h3 className="font-bold text-brand-text">{alert.title}</h3>
            <p className="text-brand-subtle text-sm mt-1">{alert.description}</p>
            <p className="text-xs text-gray-500 mt-2">{alert.timestamp}</p>
        </div>
    </div>
  );
};

const AlertsView: React.FC = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold text-brand-text mb-6">City Information & Alerts</h2>
      <div className="space-y-4">
        {ALERTS_DATA.map((alert) => (
          <AlertCard key={alert.id} alert={alert} />
        ))}
      </div>
    </div>
  );
};

export default AlertsView;
