import React from 'react';
import { ViewType } from '../../types';

interface HeaderProps {
  currentView: ViewType;
}

const Header: React.FC<HeaderProps> = ({ currentView }) => {
  return (
    <header className="bg-brand-gray border-b border-gray-700 p-4 sticky top-0 z-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-brand-text">Sustainable Smart City Assistant</h1>
          <p className="text-sm text-brand-subtle">{currentView.replace(/([A-Z])/g, ' $1').trim()}</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
