import React from 'react';
import { ViewType } from '../../types';
import { ICONS } from '../../constants';

interface SidebarProps {
  currentView: ViewType;
  setView: (view: ViewType) => void;
}

const NavItem: React.FC<{
  view: ViewType;
  currentView: ViewType;
  setView: (view: ViewType) => void;
  children: React.ReactNode;
}> = ({ view, currentView, setView, children }) => {
  const isActive = currentView === view;
  const baseClasses = "flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all duration-200";
  const activeClasses = "bg-brand-secondary text-white shadow-md";
  const inactiveClasses = "text-brand-subtle hover:bg-brand-gray hover:text-brand-text";

  return (
    <li
      onClick={() => setView(view)}
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
    >
      {children}
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  return (
    <aside className="w-64 bg-brand-gray p-4 flex flex-col border-r border-gray-700 h-screen sticky top-0">
      <div className="flex items-center space-x-3 p-3 mb-6">
        <div className="p-2 bg-brand-accent rounded-lg">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-white">SmartCity AI</h2>
      </div>

      <nav>
        <ul className="space-y-2">
          <NavItem view={ViewType.Dashboard} currentView={currentView} setView={setView}>
            {ICONS.Dashboard}
            <span>Dashboard</span>
          </NavItem>
          <NavItem view={ViewType.ResidentHub} currentView={currentView} setView={setView}>
            {ICONS.ResidentHub}
            <span>Resident Hub</span>
          </NavItem>
          <NavItem view={ViewType.CityAlerts} currentView={currentView} setView={setView}>
            {ICONS.CityAlerts}
            <span>City Alerts</span>
          </NavItem>
        </ul>
      </nav>

      <div className="mt-auto p-4 bg-brand-gray rounded-lg border border-gray-700 text-center">
        <p className="text-sm text-brand-subtle">
          Making our city smarter and greener, together.
        </p>
        <div className="mt-3 h-1 w-12 bg-brand-accent mx-auto rounded-full"></div>
      </div>
    </aside>
  );
};

export default Sidebar;
