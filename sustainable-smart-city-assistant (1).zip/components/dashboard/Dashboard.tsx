import React, { useState, useCallback } from 'react';
import { METRICS_DATA } from '../../constants';
import { Metric } from '../../types';
import { getSustainabilityInsights } from '../../services/geminiService';
import MetricCard from './MetricCard';
import InsightModal from '../common/InsightModal';

const Dashboard: React.FC = () => {
  const [modalData, setModalData] = useState<{ metric: Metric | null, content: string }>({ metric: null, content: '' });
  const [isLoading, setIsLoading] = useState(false);

  const handleGetInsights = useCallback(async (metric: Metric) => {
    setIsLoading(true);
    setModalData({ metric, content: '' });
    
    const dataString = JSON.stringify(metric.data);
    const insights = await getSustainabilityInsights(metric.title, dataString);
    
    setModalData({ metric, content: insights });
    setIsLoading(false);
  }, []);

  const closeModal = () => {
    setModalData({ metric: null, content: '' });
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {METRICS_DATA.map((metric) => (
          <MetricCard
            key={metric.id}
            metric={metric}
            onGetInsights={handleGetInsights}
          />
        ))}
      </div>
      <InsightModal
        isOpen={!!modalData.metric}
        onClose={closeModal}
        title={modalData.metric?.title || ''}
        content={modalData.content}
        isLoading={isLoading}
      />
    </>
  );
};

export default Dashboard;
