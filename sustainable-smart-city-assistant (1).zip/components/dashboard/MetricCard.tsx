import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Metric } from '../../types';

interface MetricCardProps {
  metric: Metric;
  onGetInsights: (metric: Metric) => void;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric, onGetInsights }) => {
  return (
    <div className="bg-brand-gray border border-gray-700 rounded-xl p-6 flex flex-col justify-between shadow-lg hover:shadow-brand-secondary/20 hover:border-brand-secondary/50 transition-all duration-300">
      <div>
        <h3 className="text-lg font-semibold text-brand-text">{metric.title}</h3>
        <p className="text-sm text-brand-subtle mb-4">{metric.description}</p>
        <div className="flex items-baseline space-x-2 mb-4">
          <span className="text-4xl font-bold" style={{ color: metric.color }}>{metric.value}</span>
          <span className="text-lg text-brand-subtle">{metric.unit}</span>
        </div>
        <div className="h-20 w-full mb-4">
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={metric.data} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                    <XAxis dataKey="name" hide />
                    <YAxis domain={['dataMin - 1', 'dataMax + 1']} hide />
                    <Tooltip 
                        contentStyle={{ 
                            backgroundColor: '#161b22', 
                            border: '1px solid #30363d',
                            borderRadius: '0.5rem',
                        }} 
                        labelStyle={{ color: '#e6edf3' }} 
                        itemStyle={{ color: metric.color, fontWeight: 'bold' }}
                    />
                    <Line type="monotone" dataKey={metric.dataKey} stroke={metric.color} strokeWidth={2} dot={false} />
                </LineChart>
            </ResponsiveContainer>
        </div>
      </div>
      <button
        onClick={() => onGetInsights(metric)}
        className="w-full bg-brand-secondary text-white font-semibold py-2 px-4 rounded-lg hover:bg-opacity-80 transition-colors duration-200"
      >
        Get AI Insights
      </button>
    </div>
  );
};

export default MetricCard;
